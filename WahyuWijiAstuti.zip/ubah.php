<?php 
require 'functions.php';

$id = $_GET["id"];
$siswa = query("SELECT * FROM siswa WHERE id = $id")[0];





if( isset($_POST["submit"]) ) {

	if( ubah($_POST) > 0 ) {

		echo "
		<script>
			alert('data berhasil diubah!');
			document.location.href = 'index.php';
		</script>
		";
	} else {
		echo "
		<script>
			alert('data gagal diubah!');
			document.location.href = 'index.php';
		</script>
		";
	}
 

 
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Ubah data mahasiswa</title>
</head>
<body>
	<h1>Ubah data mahasiswa</h1>

	<form action="" method="post">
		<input type="hidden" name="id" value="<?= $siswa["id"]; ?> ">
		<ul>
			<li>
				<label for="nama">NAMA : </label>
				<input type="text" name="nama" id="nama" required value="<?= $siswa["nama"]?>">
			</li>
			<li>
				<label for="nis">NIS : </label>
				<input type="text" name="nis" id="nis" value="<?= $siswa["nis"]?>">
			</li>
			
			<li>
				<label for="email">Email : </label>
				<input type="text" name="email" id="email" value="<?= $siswa["email"]?>">
			</li>
			<li>
				<label for="jurusan">Jurusan : </label>
				<input type="text" name="jurusan" id="jurusan" value="<?= $siswa["jurusan"]?>">
			</li>
			<li>
				<li>
				<label for="gambar">Gambar : </label>
				<input type="text" name="gambar" id="gambar" value="<?= $siswa["nama"]?>">
			</li> 
			<li>
				<button type="submit" name="submit">Ubah Data!</button>
			</li>
			</li>


		</ul>

	</form>

</body>
</html>