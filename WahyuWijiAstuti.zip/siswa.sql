-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2018 at 03:25 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `phpdasar`
--

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `nis` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `jurusan` varchar(100) DEFAULT NULL,
  `gambar` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id`, `nama`, `nis`, `email`, `jurusan`, `gambar`) VALUES
(48, 'Agil Dwi Febrianto', '14900', 'agilfebrian46@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(50, 'Akbar Ramadhani', '14901', 'akbar.radai123@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(52, 'Ardhia Rahmahayati', '14902', 'Ardhiarahm@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(53, 'Deni Juli Setiawan', '14903', 'bang68055@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(56, 'Dewi Sinta', '14904', 'sintapacor123@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(57, 'Dieska Syawala Nur Rizqia', '14905', 'dieskasyawala@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(64, 'Ika Siti Watiroh', '14910', 'ika.sitiwatiroh17@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(65, 'Ira Rahmawati', '14911', 'irarahmawati007@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(68, 'Muhammad Diky Firmansyah', '14914', 'mdikif10@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(69, 'Muhammad Saiful Abdulah', '14915', 'saifulmuhammad414@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(72, 'Rafi Maulana Akhmad', '14918', 'rafimaulanaakhmad@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(75, 'Riski Destu Rahman', '14921', 'riskirahman749@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(80, 'Frensae Rizky Ariessanda', '14906', 'Sanda4907@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(81, 'Gita Tri Wahyuni', '14907', 'gitatriwahyuni9a@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(82, 'Hamzah Tokhifur Falakhudin', '14908', 'none', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(86, 'Karisma Tantri', '14912', 'Karismaa197@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(87, 'Khusnaini', '14913', 'khusnainineni1@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(90, 'Muhammad Zidane Galih Tegar', '14916', 'zidangalih88@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(91, 'Nabila Pramadani', '14917', 'nabilapra450@gmail.com', 'Rekayasa Perangakat Lunak', 'rplskansa.png'),
(93, 'Rani Rahma Fika', '14919', 'ranirahma051@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(94, 'Risqi Ardiansyah', '14920', 'gilangmobile157@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(96, 'Rizky Akbar Wahyu Putranto', '14922', 'rizalpuput58@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(97, 'Samuel Kuncoro', '14923', 'none', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(98, 'Satya Dhiaz Anggraeni', '14924', 'on.040716@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(99, 'Silvester Erlangga Setya Pamungkas', '14925', 'Silvester.erlangga909@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(100, 'Sri Sulastri', '14926', 'Serinsry@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.jpg'),
(102, 'Tri Ersha Septanagria', '14928', 'none', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(104, 'Wahyu Febrianto', '14930', 'febriantowahyu63@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(105, 'Wahyu Wiji Astuti', '14931', 'wwaayasthoran1106@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(106, 'Widya Dicky Pamungkas', '14932', 'dickypamungkas75@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(108, 'Zarra Faizah Zain', '14934', 'zarrafaizahzain@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(110, 'Tio Rahman Sofani', '14927', 'none', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(112, 'Vena Yulia Wardani', '14929', 'venayulia06@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(116, 'Yoga Harist Fitrian', '14933', 'yogaharist2001@gmail.com', 'Rekayasa Perangkat Lunak', 'rplskansa.png'),
(118, 'Aagien Muhammad Farhan Pramadhani', '14988', 'none', 'Rekayasa Perangkat Lunak', 'rplskansa.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
